Latex Beamer Template for Presentations (University of Basel, Department of Mathematics and Computer Science, DBIS)
